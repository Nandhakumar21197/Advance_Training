package com.corejava.problemstatement3_1;
public abstract class Abstract
{
public abstract void Play();
}


