package com.corejava.problemstatement6_3;


	import java.util.Comparator;
	
	public class EmployeeComparator implements Comparator<Employee> {

	    @Override
	    public int compare(Employee object1, Employee object2) {
	        return object1.getname().compareTo(object2.getname());
	    }
	
	}
