package com.corejava.problemstatement1_1;

import java.util.Scanner;

public class Evennumber {

	public static void main(String[] args) {
		 

		 Scanner scan = new Scanner(System.in);
		  System.out.println("Enter the n value : ");
	      int n = scan.nextInt();

		  for (int i = 1; i <= n; i++) {
			 
		  if (i % 2 == 0) {
	 
		  System.out.println(i + " It is an Even Number");

		   }
		  
		   else {
			   System.out.println(i + "It is not an Even Number");
		   }
		  }
		   

		  }

		}