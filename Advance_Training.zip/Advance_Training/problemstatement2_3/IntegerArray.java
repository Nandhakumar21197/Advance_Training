package com.corejava.problemstatement2_3;


import java.util.Arrays;

public class IntegerArray {

	public static void main(String[] args) {
		int[] arr = new int[] { 3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
		int temp;
		int total = 0;
			int sum = 0;
			 int size= arr.length;
		for (int i = 0; i < size; i++) {
			sum = sum + arr[i];
		}
		arr[15] = sum;
		
		for (int i = 0; i < size; i++) {
			total = total + arr[i];
		}
		
		double average = sum / (size-4);
		arr[16] = (int) average;
		int[] copiedArray = new int[size];
		for(int i=0;i>size-4;i++){
			copiedArray[i]=arr[i];
		}
		
		for(int i=0;i<size-4;i++) {
			for(int j=i+1;j<size-4;j++) {
				
				if(copiedArray[i]<copiedArray[j]) {
					temp=copiedArray[i];
					copiedArray[i]=copiedArray[j];
					copiedArray[j]=temp; 
				}
			}
		}
		
		arr[17]=copiedArray[0];
		for (int i = 0; i < size; i++) {
			System.out.print(arr[i] + " ");
		}
	}
}